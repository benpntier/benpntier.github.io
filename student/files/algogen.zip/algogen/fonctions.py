# -*- coding: utf-8 -*-

# --- ALGORITHME GENETIQUE ---
# ------ PROGRAMME PAR -------
# ----- LEO BERGOUGNOUX ------
# ------------ ET ------------
# ----- BENOIT PANNETIER -----
# ----------- 2018 -----------

# --- IMPORTS ---
from random import randint
from copy import deepcopy
import matplotlib.pyplot as plt
import numpy as np


# --- CROISEMENT ---
def croiser(parentA, parentB, nbGenes):
    enfant=[]
    section = randint(1,nbGenes-1)

    #on copie les genes du parent A (avant section)
    for gene in range(0,section):
            enfant.append(parentA[gene])

    #on copie les genes du parent B (apres section)
    for gene in range(section,nbGenes):
            if not (parentB[gene] in enfant):                                   #Si le gene courant de parent B n'est pas dans enfant
                enfant.append(parentB[gene])                                    #   on le copie dans enfant

    #pour chaque gene de parentB (qui possede tous les genes)
    for gene in parentB:
        if not (gene in enfant):                                                #Si le gene n'est pas dans enfant
            enfant.append(gene)                                                 #   on l'ajoute dans enfant
    return enfant


# --- MUTATION ---
def muter(individu, nbGenes, taux_mutation):
    if randint(0,100) < taux_mutation:                                          #si l'individu est sujet à mutation
        geneA=randint(0,nbGenes-1)                                              #on sélectionne au hasard un de ses gènes
        geneB=geneA                                                             #on sélectionne un deuxième gène, identique au premier
        while geneB==geneA:                                                     #tant que les deux gènes sont les mêmes
            geneB=randint(0,nbGenes-1)                                          #   on sélectionne au hasard le 2e gène (pour assurer qu'ils soient différents)
        individu[geneA],individu[geneB]=individu[geneB],individu[geneA]         #on intervertit les deux gènes choisis


# --- FITNESS ---
def calculFitness(population, distances):
    fitness = [-1]*len(population)                                              #initialisation

    for individu in range (len(population)):                                    #pour chaque individu/chemin de la population
        distanceTotale=0
        for gene in range (len(population[individu])-1):                        #pour chaque gene/ville

            #variable : distance entre la ville courante et la ville suivante
            distDeVilleAVilleSuiv = distances[population[individu][gene]-1][population[individu][gene+1]-1]
            #variable : distance entre la derniere ville et la premiere ville du chemin
            distDeDerniereVilleAPremiereVille = distances[population[individu][gene+1]-1][population[individu][0]-1]

            #incrementer la distance totale avec la distance entre deux villes
            distanceTotale += distDeVilleAVilleSuiv

        #terminer avec la distance entre la derniere ville et la premiere ville
        distanceTotale += distDeDerniereVilleAPremiereVille

        #calcul de la fitness de chaque chemin (inverse de la distance totale)
        fitness[individu] = 1/distanceTotale
    return fitness


# --- ALGORITHME GENETIQUE ---
def algogenetique(population, nbGenes, fitness, distances, nb_generation_min, nb_generation_max, taux_mutation, show=True):
    #initialisation des variables
    nbIndividus=len(population)                                                 #taille de la population / nombre de chemins
    nGeneration=1                                                               #on initialise un compteur de generations
    arret = False                                                               #initialise un booleen pour la boucle

    #initialisation de la courbe 'évolution de la fitness'
    if show:
        evolution = plt.figure(2)
        xGeneration=[]                                                          #abscisses (nombre de générations)
        yFitnessMax=[]                                                          #ordonnées (fitness maximum)
        yFitnessMoy=[]                                                          #ordonnées (fitness moyenne)

    while (not arret):                                                          #tant que le booleen 'arret' est a FAUX
        if show:print("\nGÉNÉRATION n°"+str(nGeneration))
        fitness = calculFitness(population, distances)                            #calcul des fitness
        fitnessPrec = max(fitness)                                              #sauvegarde de la fitness de la génération

        #on ajoute les fitness à la courbe
        if show:
            xGeneration.append(nGeneration-1)
            yFitnessMax.append(max(fitness))
            yFitnessMoy.append(np.mean(fitness))

        #on génère la descendance
        descendance=[]
        enfant=0                                                                #compteur de descendants
        if show:print("... Croisements ...")
        for parentA in population:                                              #pour chaque parent A
            for parentB in population:                                          #pour chaque parent B
                if parentA != parentB:                                          #si les deux parents sont differents
                    descendance.append(croiser(parentA,parentB,nbGenes))        #   on les croise
                    muter(descendance[enfant], nbGenes, taux_mutation)          #   on tente une mutation de leur enfant
                    enfant+=1

        if show:print("... Création de la nouvelle population ...")
        if len(descendance) > 0:
            fitDescendance = calculFitness(descendance, distances)                #calcul de la fitness de la descendance
            fitMinimum = np.percentile(fitDescendance,75)                       #on détermine le troisième quartile des fitness de la descendance
            nbDescendants = len(descendance)

            #sélection de la descendance et création de la nouvelle population
            i = 0
            while i < nbDescendants and nbDescendants > nbIndividus:            #tant que l'on n'a pas trie tous les descendants et que le nombre de descendants est superieur au nombre de parents
                if fitDescendance[i] < fitMinimum:                              #si la fitness de l'enfant en cours est inferieur au quartile de la fitness de la descendance
                    del descendance[i]                                          #   on supprime l'enfant
                    del fitDescendance[i]                                       #   on supprime sa fitness
                    nbDescendants-=1                                            #   on décrémente le nombre de descendants
                else:
                    i+=1                                                        #on passe a l'enfant suivant
        population=population+descendance                                       #on crée une nouvelle population à partir des parents et des enfants (selectionnes)
        fitness=calculFitness(population, distances)                              #calcul de la fitness de la nouvelle population

        if show:print("... Sélection naturelle ...")
        cpFitness=deepcopy(fitness)                                             #on copie la fitness de la population pour pouvoir la trier
        cpPopulation=deepcopy(population)                                       #on copie la population pour pouvoir leur donner un rang

        #selection naturelle (tri par insertion)
        for individu in range (1, len(cpFitness)):                              #pour chaque individu à trier
            fit = cpFitness[individu]
            rang = individu
            while (rang > 0 and cpFitness[rang-1] < fit):                       #tant que l'on n'a pas trouve le rang de l'individu en cours
                cpFitness[rang] = cpFitness[rang-1]                             #   on se deplace dans les individus ordonnes
                rang-=1                                                         #   on decremente son rang
            cpFitness[rang] = fit                                               #on insert la fitness de l'individu a son rang
            cpPopulation[rang]=population[individu]                             #on insert l'individu dans la population a son rang

        #on sélectionne les 'nbIndividus' meilleurs chemins
        population=cpPopulation[:nbIndividus]

        #condition d'arret : si on a un nombre minimum de générations et que la fitness stagne (ou que l'on a atteint un nombre max de generations)
        if (nGeneration >= nb_generation_min and max(fitness) == fitnessPrec) or nGeneration == nb_generation_max:
            arret=True                                                          #alors on s'arrete
        else:
            nGeneration+=1                                                      #sinon on continue l'algorithme

    #affichage de la courbe 'évolution de la fitness'
    if show:
        plt.plot(xGeneration,yFitnessMax,label="Fitness maximum")               #courbe 'fitness maximum'
        plt.plot(xGeneration,yFitnessMoy,label="Fitness moyenne")               #courbe 'fitness moyenne'
        plt.legend(loc="lower right")                                           #on affiche la légende
        plt.xlabel("Nombre de générations")                                     #intitulé des abscisses
        plt.ylabel("Fitness")                                                   #intitulé des ordonnées
        plt.title('Évolution de la fitness au fil des générations')             #nom du graphique
        evolution.show()

    #on retourne la population finale
    return population
