# -*- coding: utf-8 -*-

# --- ALGORITHME GENETIQUE ---
# ------ PROGRAMME PAR -------
# ----- LEO BERGOUGNOUX ------
# ------------ ET ------------
# ----- BENOIT PANNETIER -----
# ----------- 2018 -----------

# --- IMPORTS ---
from random import randint, shuffle
from copy import deepcopy
from math import sqrt
from fonctions import algogenetique, calculFitness
import matplotlib.pyplot as plt
import numpy as np
import time

# --- VALEURS A DEMANDER ET CONSTANTES ---
nbChemins = int(input("Combien de chemins doivent être générés ? "))
cercle = input("Voulez-vous générer un cercle (o/n) ? ")
if cercle.lower() != "o" and cercle.lower() != "oui":
    nbVilles = int(input("Par combien de villes doit passer le voyageur ? "))
else:
    nbVilles = 16
nb_generation_min=nbChemins/10
nb_generation_max=100
taux_mutation=10


# --- GENERER COORDONNEES ---
if cercle.lower() != "o" and cercle.lower() != "oui":
    listeCoordonnees=[]
    print("\n... Élaboration des coordonnées ...")
    for ville in range (nbVilles):                                              #pour chaque ville
        for coordonnee in range (2):                                            #
            listeCoordonnees.append([])                                         #   on ajoute des coordonnees dans une liste [x, y] dont chaque valeur est aléeatoire et comprise est -500 et 500
            listeCoordonnees[ville].append(randint(-500,500))                   #
else: #générer les coordonnées des points d'un cercle
    listeCoordonnees=[[0,300], [110,270], [200,200], [270,110], [300, 0], [270, -110], [200, -200], [110, -270], [0, -300], [-110, -270], [-200,-200], [-270, -110], [-300, 0], [-270, 110], [-200, 200], [-110, 270]]
    print("")

# --- AFFICHER LES VILLES ---
x=[]
y=[]
chemin = plt.figure(1)
for ville in range(nbVilles):
    x.append(listeCoordonnees[ville][0])                                        #on crée une liste a partir de toutes les abscisses
    y.append(listeCoordonnees[ville][1])                                        #on crée une liste a partir de toutes les ordonnées
plt.scatter(x, y, s=15)                                                         #afficher un point de taille 15 pour chaque coordonnées (x,y)
plt.title('Carte des villes à visiter')
chemin.show()


# --- GENERER MATRICE DES DISTANCES ---
print("... Calcul des distances entre les villes ...")
distances = [[-1]*nbVilles for i in range(nbVilles)]                            #initialiser une liste vide (remplie de -1)
for ville1 in range (nbVilles):
    for ville2 in range (nbVilles):
        if distances[ville1][ville2] == (-1):                                   #si la distance entre deux villes n'a pas encore été définie
            if (ville1 == ville2):                                              #   si les deux villes sont la même
                distances[ville1][ville2]=0                                     #       on indique 0 comme distance entre ville1 et ville2
                distances[ville2][ville1]=0                                     #       et entre ville2 et ville1
            else: #sinon
                #on calcule la distance entre ville1 et ville2 : racinecaree((xB-xA)²+(yB-yA)²)
                distanceCalculee = round(sqrt(((listeCoordonnees[ville2][0] - listeCoordonnees[ville1][0])**2) + ((listeCoordonnees[ville2][1] - listeCoordonnees[ville1][1])**2)))
                #on ajoute cette distance dans la matrice, entre ville1 et ville2 puis entre ville2 et ville1
                distances[ville1][ville2]=distanceCalculee
                distances[ville2][ville1]=distanceCalculee


# --- GENERER POPULATION INITIALE (GENERATION 0) ---
print("... Création de la population initiale ...")
population=[]
listeVilles = list(range(1,nbVilles+1))                                         #Liste des villes dans l'ordre
for chemin in range(0,nbChemins):                                               #Dans chaque chemin
    population.append(deepcopy(listeVilles))                                    #   on copie la liste des villes
    shuffle(population[chemin])                                                 #   que l'on mélange aléatoirement
fitness = [-1]*nbChemins                                                        #on initialise la liste des fitness


# --- AFFICHER FITNESS EN FONCTION DU NOMBRE DE CHEMINS ---
fig3 = input("Voulez-vous afficher l'évolution de la fitness en fonction du nombre de chemins (o/n) ? ")
print("")
if fig3 != "n" and fig3 != "non" and nbChemins > 20:
    xChemins = []
    yFitness = []
    for nombre in range (int(nbChemins/20), nbChemins, int(nbChemins/20)):      #on lance l'algo genetique pour des nombres de chemins differents
        pop = algogenetique(population[:nombre], nbVilles, fitness, distances, nombre/10, nb_generation_max, taux_mutation, show=False)
        xChemins.append(nombre)
        yFitness.append(max(calculFitness(pop,distances)))
        print("... Calculs pour une population de "+str(nombre)+" chemins ...")
    print("")


# --- ALGORITHME GENETIQUE ---
debut = time.time()                                                             #on commence à enregistrer le temps d'exécution
print("... Début de l'algorithme génétique ...\n")
population=algogenetique(population, nbVilles, fitness, distances, nb_generation_min, nb_generation_max, taux_mutation)
fin = time.time()
print("\nFin de l'algorithme génétique. Temps d'exécution : "+str(round(fin - debut, 4))+" secondes.")

if fig3 != "n" and fig3 != "non" and nbChemins > 50:                            #représenter l'évolution de la fitness en fonction du nombre de chemins
    evolNbChemins = plt.figure(3)
    xChemins.append(nbChemins)
    yFitness.append(max(calculFitness(pop,distances)))
    plt.plot(xChemins,yFitness)
    plt.xlabel("Nombre de chemins")
    plt.ylabel("Fitness")
    plt.title("Évolution de la fitness en fonction du nombre de chemins générés")
    evolNbChemins.show()


# --- AFFICHER LE RESULTAT ---
chemin = plt.figure(1)
x=[]
y=[]
for ville in population[0]:
    x.append(listeCoordonnees[ville-1][0])                                      #on crée une liste à  partir de toutes les abscisses
    y.append(listeCoordonnees[ville-1][1])                                      #on crée une liste à  partir de toutes les ordonnées
#on relie chaque ville du chemin
plt.plot(x,y)
#on relie la derniere ville et la premiere du chemin
x2=np.array([listeCoordonnees[population[0][-1]-1][0], listeCoordonnees[population[0][0]-1][0]])
y2=np.array([listeCoordonnees[population[0][-1]-1][1], listeCoordonnees[population[0][0]-1][1]])
plt.plot(x2,y2)
plt.axis('equal')
chemin.show()
